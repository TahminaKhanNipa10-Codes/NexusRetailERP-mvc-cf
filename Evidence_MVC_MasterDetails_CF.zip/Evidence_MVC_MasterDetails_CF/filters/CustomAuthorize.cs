﻿using Evidence_MVC_MasterDetails_CF.Models;
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Evidence_MVC_MasterDetails_CF.Filters
{
    public class CustomAuthorize : AuthorizeAttribute
    {
        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            if (!filterContext.HttpContext.User.Identity.IsAuthenticated)
            {
                filterContext.Result = new RedirectToRouteResult(
                    new RouteValueDictionary(new { controller = "Account", action = "Login" })
                );
                return;
            }

            if (filterContext.HttpContext.User.IsInRole("Admin"))
            {
                return;
            }

            var controller = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;
            var action = filterContext.ActionDescriptor.ActionName;
            var user = filterContext.HttpContext.User;

            using (var db = new ApplicationDbContext())
            {
                var userId = user.Identity.GetUserId();
                var userObj = db.Users.Find(userId);

                if (userObj == null)
                {
                    filterContext.Result = new RedirectToRouteResult(
                        new RouteValueDictionary(new { controller = "Account", action = "Login" })
                    );
                    return;
                }

                var userRoles = userObj.Roles.Select(r => r.RoleId).ToList();

                bool hasPermission = db.RolePermissions.Any(p =>
                    userRoles.Contains(p.RoleId) &&
                    p.ControllerName == controller &&
                    p.ActionName == action);

                if (!hasPermission)
                {
                    var authenticationManager = filterContext.HttpContext.GetOwinContext().Authentication;
                    authenticationManager.SignOut(Microsoft.AspNet.Identity.DefaultAuthenticationTypes.ApplicationCookie);

                    filterContext.Controller.TempData["Message"] = "Unauthorized access! Please login with an authorized account.";

                    filterContext.Result = new RedirectToRouteResult(
                        new RouteValueDictionary(new { controller = "Account", action = "Login" })
                    );
                }
            }
        }
    }

}