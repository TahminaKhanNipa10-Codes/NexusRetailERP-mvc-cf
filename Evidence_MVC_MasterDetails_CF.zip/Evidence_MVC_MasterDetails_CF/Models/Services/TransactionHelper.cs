using System;
using System.Data;
using System.Threading.Tasks;

namespace Evidence_MVC_MasterDetails_CF.Models.Services
{
    /// <summary>
    /// Helper class for managing database transactions with a simplified API
    /// Automatically handles rollback on exceptions
    /// </summary>
    public static class TransactionHelper
    {
        /// <summary>
        /// Executes an asynchronous operation within a transaction
        /// </summary>
        /// <param name="context">The database context</param>
        /// <param name="operation">The async operation to execute</param>
        /// <returns>Task representing the asynchronous operation</returns>
        public static async Task ExecuteInTransactionAsync(
            ApplicationDbContext context,
            Func<ApplicationDbContext, Task> operation)
        {
            using (var transactionService = new TransactionService(context))
            {
                await transactionService.BeginTransactionAsync();
                try
                {
                    await operation(context);
                    await transactionService.CommitAsync();
                }
                catch (Exception ex)
                {
                    await transactionService.RollbackAsync();
                    throw new InvalidOperationException("Transaction failed and was rolled back", ex);
                }
            }
        }

        /// <summary>
        /// Executes an asynchronous operation within a transaction and returns a result
        /// </summary>
        /// <typeparam name="T">The return type</typeparam>
        /// <param name="context">The database context</param>
        /// <param name="operation">The async operation to execute</param>
        /// <returns>Task of T representing the asynchronous operation</returns>
        public static async Task<T> ExecuteInTransactionAsync<T>(
            ApplicationDbContext context,
            Func<ApplicationDbContext, Task<T>> operation)
        {
            using (var transactionService = new TransactionService(context))
            {
                await transactionService.BeginTransactionAsync();
                try
                {
                    var result = await operation(context);
                    await transactionService.CommitAsync();
                    return result;
                }
                catch (Exception ex)
                {
                    await transactionService.RollbackAsync();
                    throw new InvalidOperationException("Transaction failed and was rolled back", ex);
                }
            }
        }

        /// <summary>
        /// Executes an operation within a transaction with a specific isolation level
        /// </summary>
        /// <param name="context">The database context</param>
        /// <param name="isolationLevel">The isolation level for the transaction</param>
        /// <param name="operation">The async operation to execute</param>
        /// <returns>Task representing the asynchronous operation</returns>
        public static async Task ExecuteInTransactionAsync(
            ApplicationDbContext context,
            IsolationLevel isolationLevel,
            Func<ApplicationDbContext, Task> operation)
        {
            using (var transactionService = new TransactionService(context))
            {
                await transactionService.BeginTransactionAsync(isolationLevel);
                try
                {
                    await operation(context);
                    await transactionService.CommitAsync();
                }
                catch (Exception ex)
                {
                    await transactionService.RollbackAsync();
                    throw new InvalidOperationException("Transaction failed and was rolled back", ex);
                }
            }
        }

        /// <summary>
        /// Executes an operation within a transaction with a specific isolation level and returns a result
        /// </summary>
        /// <typeparam name="T">The return type</typeparam>
        /// <param name="context">The database context</param>
        /// <param name="isolationLevel">The isolation level for the transaction</param>
        /// <param name="operation">The async operation to execute</param>
        /// <returns>Task of T representing the asynchronous operation</returns>
        public static async Task<T> ExecuteInTransactionAsync<T>(
            ApplicationDbContext context,
            IsolationLevel isolationLevel,
            Func<ApplicationDbContext, Task<T>> operation)
        {
            using (var transactionService = new TransactionService(context))
            {
                await transactionService.BeginTransactionAsync(isolationLevel);
                try
                {
                    var result = await operation(context);
                    await transactionService.CommitAsync();
                    return result;
                }
                catch (Exception ex)
                {
                    await transactionService.RollbackAsync();
                    throw new InvalidOperationException("Transaction failed and was rolled back", ex);
                }
            }
        }
    }
}
