using System;
using System.Data;
using System.Data.Entity;
using System.Threading.Tasks;

namespace Evidence_MVC_MasterDetails_CF.Models.Services
{
    /// <summary>
    /// Service for managing database transactions with Commit/Rollback functionality
    /// Ensures data consistency and integrity across multiple database operations
    /// </summary>
    public class TransactionService : IDisposable
    {
        private readonly ApplicationDbContext _context;
        private System.Data.Entity.DbContextTransaction _transaction;
        private bool _disposed = false;

        public TransactionService(ApplicationDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        /// <summary>
        /// Begins a new database transaction
        /// </summary>
        /// <returns>Task representing the asynchronous operation</returns>
        public async Task BeginTransactionAsync()
        {
            try
            {
                _transaction = _context.Database.BeginTransaction();
                await Task.CompletedTask;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to begin transaction", ex);
            }
        }

        /// <summary>
        /// Begins a transaction with specified isolation level
        /// </summary>
        /// <param name="isolationLevel">The isolation level for the transaction</param>
        /// <returns>Task representing the asynchronous operation</returns>
        public async Task BeginTransactionAsync(IsolationLevel isolationLevel)
        {
            try
            {
                _transaction = _context.Database.BeginTransaction(isolationLevel);
                await Task.CompletedTask;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to begin transaction with isolation level", ex);
            }
        }

        /// <summary>
        /// Commits the current transaction
        /// </summary>
        /// <returns>Task representing the asynchronous operation</returns>
        public async Task CommitAsync()
        {
            try
            {
                if (_transaction != null)
                {
                    await _context.SaveChangesAsync();
                    _transaction.Commit();
                }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to commit transaction", ex);
            }
        }

        /// <summary>
        /// Rolls back the current transaction
        /// </summary>
        /// <returns>Task representing the asynchronous operation</returns>
        public async Task RollbackAsync()
        {
            try
            {
                if (_transaction != null)
                {
                    _transaction.Rollback();
                    await Task.CompletedTask;
                }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to rollback transaction", ex);
            }
        }

        /// <summary>
        /// Saves changes to the database within the current transaction
        /// </summary>
        /// <returns>Number of state entries written to the database</returns>
        public async Task<int> SaveChangesAsync()
        {
            try
            {
                if (_transaction == null)
                {
                    throw new InvalidOperationException("No active transaction. Call BeginTransactionAsync first.");
                }
                return await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Rollback on error
                if (_transaction != null)
                {
                    _transaction.Rollback();
                }
                throw new InvalidOperationException("Failed to save changes", ex);
            }
        }

        /// <summary>
        /// Gets the current transaction
        /// </summary>
        public System.Data.Entity.DbContextTransaction CurrentTransaction => _transaction;

        /// <summary>
        /// Checks if a transaction is currently active
        /// </summary>
        public bool IsTransactionActive => _transaction != null;

        /// <summary>
        /// Disposes the transaction and cleanup resources
        /// </summary>
        public void Dispose()
        {
            if (!_disposed)
            {
                _transaction?.Dispose();
                _disposed = true;
            }
            GC.SuppressFinalize(this);
        }
    }
}
