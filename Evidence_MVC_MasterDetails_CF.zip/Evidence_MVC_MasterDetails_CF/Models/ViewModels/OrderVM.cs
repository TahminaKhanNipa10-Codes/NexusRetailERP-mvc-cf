﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Evidence_MVC_MasterDetails_CF.Models.ViewModels
{
    public class OrderVM
    {
        public OrderVM()
        {
            this.OrderDetails = new List<OrderDetail>();
            this.OrderDate = DateTime.Now;
        }

        // Customer & Order (Master)
        public string CustomerName { get; set; }
        public string ContactNumber { get; set; }
        public string ContactAddress { get; set; }
        public DateTime OrderDate { get; set; }

        // Order Details (List for Table)
        public List<OrderDetail> OrderDetails { get; set; }

    }
}