﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Evidence_MVC_MasterDetails_CF.Startup))]
namespace Evidence_MVC_MasterDetails_CF
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
