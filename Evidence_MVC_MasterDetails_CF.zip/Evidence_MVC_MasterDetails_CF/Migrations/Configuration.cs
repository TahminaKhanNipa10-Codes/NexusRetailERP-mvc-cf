﻿namespace Evidence_MVC_MasterDetails_CF.Migrations
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using Evidence_MVC_MasterDetails_CF.Models; // Apnar model er sothik namespace nishchit korun

    internal sealed class Configuration : DbMigrationsConfiguration<Evidence_MVC_MasterDetails_CF.Models.ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(Evidence_MVC_MasterDetails_CF.Models.ApplicationDbContext context)
        {
            // 1. Seed Product Categories
            context.ProductCategories.AddOrUpdate(c => c.CategoryName,
                new ProductCategory { CategoryName = "Computers", CategoryDescription = "Laptops, Desktops and Accessories" },
                new ProductCategory { CategoryName = "Smartphones", CategoryDescription = "Mobile Phones and Gadgets" }
            );
            context.SaveChanges(); // ID generation er jonno save kora holo

            // Category ID gulo collection theke niye asha
            int computerCatId = context.ProductCategories.First(c => c.CategoryName == "Computers").ProductCategoryId;
            int phoneCatId = context.ProductCategories.First(c => c.CategoryName == "Smartphones").ProductCategoryId;

            // 2. Seed Products
            context.Products.AddOrUpdate(p => p.ProductName,
                new Product
                {
                    ProductName = "HP ProBook 450 G10",
                    Unit = "Pcs",
                    UnitPrice = 85000.00m,
                    AvailableQuantity = 15,
                    IsActive = true,
                    ProductCategoryId = computerCatId,
                    ProductImage = "hp_probook.jpg"
                },
                new Product
                {
                    ProductName = "Dell Vostro 3520",
                    Unit = "Pcs",
                    UnitPrice = 65000.00m,
                    AvailableQuantity = 20,
                    IsActive = true,
                    ProductCategoryId = computerCatId,
                    ProductImage = "dell_vostro.jpg"
                },
                new Product
                {
                    ProductName = "Samsung Galaxy S24",
                    Unit = "Pcs",
                    UnitPrice = 95000.00m,
                    AvailableQuantity = 10,
                    IsActive = true,
                    ProductCategoryId = phoneCatId,
                    ProductImage = "samsung_s24.jpg"
                }
            );
            context.SaveChanges();

            // 3. Seed Customers
            context.Customers.AddOrUpdate(c => c.CustomerName,
                new Customer { CustomerName = "Tahmina Khan", ContactNumber = "01711223344", ContactAddress = "Chittagong, Bangladesh" },
                new Customer { CustomerName = "Arifur Rahman", ContactNumber = "01911556677", ContactAddress = "Dhaka, Bangladesh" }
            );
            context.SaveChanges();

            // Customer ID gulo retrieve kora
            int customerId1 = context.Customers.First(c => c.CustomerName == "Tahmina Khan").CustomerId;

            // Product ID o details fetch kora testing order data set up korar jonno
            var prod1 = context.Products.First(p => p.ProductName == "HP ProBook 450 G10");
            var prod2 = context.Products.First(p => p.ProductName == "Samsung Galaxy S24");

            // 4. Seed Master-Detail Data (Orders & OrderDetails)
            // Khub e dorkari check: Jeno proti run-e duplicate order insert na hoy
            if (!context.Orders.Any(o => o.CustomerId == customerId1))
            {
                var sampleOrder = new Order
                {
                    CustomerId = customerId1,
                    OrderDate = DateTime.Now.AddDays(-1),
                    TotalAmount = 180000.00m // 85000*1 + 95000*1
                };

                context.Orders.Add(sampleOrder);
                context.SaveChanges(); // Order ID generate hobar jonno parse kora holo

                var orderDetailsList = new List<OrderDetail>
                {
                    new OrderDetail
                    {
                        OrderId = sampleOrder.OrderId,
                        ProductCategoryId = computerCatId,
                        ProductId = prod1.ProductId,
                        OrderQuantity = 1,
                        OrderUnit = prod1.Unit,
                        UnitPrice = prod1.UnitPrice,
                        Amount = prod1.UnitPrice * 1
                    },
                    new OrderDetail
                    {
                        OrderId = sampleOrder.OrderId,
                        ProductCategoryId = phoneCatId,
                        ProductId = prod2.ProductId,
                        OrderQuantity = 1,
                        OrderUnit = prod2.Unit,
                        UnitPrice = prod2.UnitPrice,
                        Amount = prod2.UnitPrice * 1
                    }
                };

                context.OrderDetails.AddRange(orderDetailsList);
                context.SaveChanges();
            }
        }
    }
}