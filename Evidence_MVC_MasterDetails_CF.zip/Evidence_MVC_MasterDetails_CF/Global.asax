﻿<%@ Application Codebehind="Global.asax.cs" Inherits="Evidence_MVC_MasterDetails_CF.MvcApplication" Language="C#" %>
