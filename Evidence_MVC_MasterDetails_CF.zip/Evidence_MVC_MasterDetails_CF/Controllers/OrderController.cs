﻿using Evidence_MVC_MasterDetails_CF.Models;
using Evidence_MVC_MasterDetails_CF.Models.ViewModels;
using Evidence_MVC_MasterDetails_CF.Models.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Data.Entity;
using System.Data;
using System.Web.Mvc;

namespace Evidence_MVC_MasterDetails_CF.Controllers
{
    public class OrderController : BaseController
    {
        ApplicationDbContext db = new ApplicationDbContext();

        // Helper method to get only active products for dropdown
        private SelectList GetActiveProductsSelectList()
        {
            var activeProducts = db.Products.Where(p => p.IsActive).ToList();
            return new SelectList(activeProducts, "ProductId", "ProductName");
        }

        // GET: Order
        public ActionResult Index()
        {
            var orders = db.Orders.Include(o => o.Customer).ToList();
            return View(orders);
        }

        // GET: Order/Create
        [HttpGet]
        public ActionResult Create()
        {
            var model = new OrderVM();
            model.OrderDetails = new List<OrderDetail>();
            ViewBag.Categories = db.ProductCategories.ToList();
            ViewBag.ProductId = GetActiveProductsSelectList();
            return View(model);
        }

        // POST: Order/Create
        [HttpPost]
        public ActionResult Create(OrderVM vm, string btnAction, int? ProductId, int? Qty, int? removeIndex, int? editIndex)
        {
            if (vm.OrderDetails == null)
            {
                vm.OrderDetails = new List<OrderDetail>();
            }

            if (btnAction == "AddItem")
            {
                if (ProductId != null && Qty != null && Qty > 0)
                {
                    var product = db.Products.Find(ProductId);

                    if (product == null)
                    {
                        TempData["ErrorMessage"] = "Product not found!";
                    }
                    else if (!product.IsActive)
                    {
                        TempData["ErrorMessage"] = $"{product.ProductName} is currently inactive!";
                    }
                    else if (Qty > product.AvailableQuantity)
                    {
                        TempData["ErrorMessage"] = $"Only {product.AvailableQuantity} items available for {product.ProductName}!";
                    }
                    else
                    {
                        var existingItem = vm.OrderDetails.FirstOrDefault(x => x.ProductId == ProductId);
                        if (existingItem != null)
                        {
                            if (existingItem.OrderQuantity + Qty > product.AvailableQuantity)
                            {
                                TempData["ErrorMessage"] = $"Total quantity exceeds stock! Available: {product.AvailableQuantity}, Current: {existingItem.OrderQuantity}";
                            }
                            else
                            {
                                existingItem.OrderQuantity += Qty.Value;
                                existingItem.Amount = existingItem.OrderQuantity * existingItem.UnitPrice;
                            }
                        }
                        else
                        {
                            vm.OrderDetails.Add(new OrderDetail
                            {
                                ProductId = ProductId.Value,
                                Product = product,
                                OrderQuantity = Qty.Value,
                                UnitPrice = product.UnitPrice,
                                Amount = Qty.Value * product.UnitPrice,
                                OrderUnit = product.Unit
                            });
                        }
                    }
                }
                ModelState.Clear();
            }
            else if (btnAction == "UpdateItem")
            {
                if (editIndex != null && editIndex < vm.OrderDetails.Count && ProductId != null && Qty > 0)
                {
                    var product = db.Products.Find(ProductId);
                    if (product != null && product.IsActive)
                    {
                        if (Qty <= product.AvailableQuantity)
                        {
                            vm.OrderDetails[editIndex.Value].ProductId = ProductId.Value;
                            vm.OrderDetails[editIndex.Value].Product = product;
                            vm.OrderDetails[editIndex.Value].OrderQuantity = Qty.Value;
                            vm.OrderDetails[editIndex.Value].UnitPrice = product.UnitPrice;
                            vm.OrderDetails[editIndex.Value].Amount = Qty.Value * product.UnitPrice;
                            vm.OrderDetails[editIndex.Value].OrderUnit = product.Unit;
                        }
                        else
                        {
                            TempData["ErrorMessage"] = $"Only {product.AvailableQuantity} items available for {product.ProductName}!";
                        }
                    }
                }
                ModelState.Clear();
            }
            else if (btnAction == "RemoveItem")
            {
                if (removeIndex != null && removeIndex < vm.OrderDetails.Count)
                {
                    vm.OrderDetails.RemoveAt(removeIndex.Value);
                }
                ModelState.Clear();
            }
            else if (btnAction == "SaveOrder")
            {
                if (vm.OrderDetails != null && vm.OrderDetails.Any())
                {
                    if (string.IsNullOrEmpty(vm.CustomerName))
                    {
                        TempData["ErrorMessage"] = "Please enter customer name!";
                    }
                    else
                    {
                        try
                        {
                            using (var context = new ApplicationDbContext())
                            {
                                using (var transaction = context.Database.BeginTransaction())
                                {
                                    try
                                    {
                                        Customer cust = new Customer
                                        {
                                            CustomerName = vm.CustomerName,
                                            ContactNumber = vm.ContactNumber,
                                            ContactAddress = vm.ContactAddress
                                        };
                                        context.Customers.Add(cust);
                                        context.SaveChanges();

                                        Order order = new Order
                                        {
                                            CustomerId = cust.CustomerId,
                                            OrderDate = vm.OrderDate,
                                            TotalAmount = vm.OrderDetails.Sum(x => x.Amount)
                                        };
                                        context.Orders.Add(order);
                                        context.SaveChanges();

                                        foreach (var item in vm.OrderDetails)
                                        {
                                            item.OrderId = order.OrderId;
                                            item.Product = null;
                                            context.OrderDetails.Add(item);

                                            var product = context.Products.Find(item.ProductId);
                                            if (product != null)
                                            {
                                                product.AvailableQuantity -= item.OrderQuantity;
                                                context.Entry(product).State = EntityState.Modified;
                                            }
                                        }
                                        context.SaveChanges();
                                        transaction.Commit();

                                        return RedirectToAction("Index");
                                    }
                                    catch
                                    {
                                        transaction.Rollback();
                                        throw;
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            TempData["ErrorMessage"] = "Error saving order: " + ex.Message;
                        }
                    }
                }
                else
                {
                    TempData["ErrorMessage"] = "Please add at least one product to the order!";
                }
            }

            // Reload product details for each order detail
            if (vm.OrderDetails != null)
            {
                foreach (var detail in vm.OrderDetails)
                {
                    if (detail.ProductId > 0 && detail.Product == null)
                    {
                        detail.Product = db.Products.Find(detail.ProductId);
                    }
                }
            }

            ViewBag.Categories = db.ProductCategories.ToList();
            ViewBag.ProductId = GetActiveProductsSelectList();

            return View(vm);
        }

        // GET: Order/Details
        public ActionResult Details(int id)
        {
            var order = db.Orders
                          .Include(o => o.Customer)
                          .Include(o => o.OrderDetails.Select(d => d.Product))
                          .FirstOrDefault(o => o.OrderId == id);

            if (order == null) return HttpNotFound();
            return View(order);
        }

        // GET: Order/Delete
        public ActionResult Delete(int id)
        {
            var order = db.Orders
                          .Include(o => o.Customer)
                          .Include(o => o.OrderDetails.Select(d => d.Product))
                          .FirstOrDefault(o => o.OrderId == id);

            if (order == null) return HttpNotFound();
            return View(order);
        }

        // POST: Order/Delete
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                using (var context = new ApplicationDbContext())
                {
                    using (var transaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            var order = context.Orders.Include(o => o.OrderDetails).FirstOrDefault(o => o.OrderId == id);
                            var details = context.OrderDetails.Where(d => d.OrderId == id).ToList();

                            // Return quantities to products
                            foreach (var detail in details)
                            {
                                var product = context.Products.Find(detail.ProductId);
                                if (product != null)
                                {
                                    product.AvailableQuantity += detail.OrderQuantity;
                                    context.Entry(product).State = EntityState.Modified;
                                }
                            }

                            context.OrderDetails.RemoveRange(details);
                            context.Orders.Remove(order);
                            context.SaveChanges();
                            transaction.Commit();
                        }
                        catch
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }

                TempData["SuccessMessage"] = "Order deleted successfully!";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error deleting order: " + ex.Message;
                return RedirectToAction("Index");
            }
        }

        // GET: Order/Edit/5
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var order = db.Orders
                          .Include(o => o.Customer)
                          .Include(o => o.OrderDetails.Select(d => d.Product))
                          .FirstOrDefault(o => o.OrderId == id);

            if (order == null) return HttpNotFound();

            // Load data in OrderVM
            var model = new OrderVM
            {
                CustomerName = order.Customer.CustomerName,
                ContactNumber = order.Customer.ContactNumber,
                ContactAddress = order.Customer.ContactAddress,
                OrderDate = order.OrderDate,
                OrderDetails = order.OrderDetails.ToList()
            };

            ViewBag.Categories = db.ProductCategories.ToList();
            ViewBag.ProductId = GetActiveProductsSelectList();
            return View(model);
        }

        // POST: Order/Edit/5
        [HttpPost]
        public ActionResult Edit(OrderVM vm, string btnAction, int? ProductId, int? Qty, int? removeIndex, int id, int? editIndex)
        {
            if (vm.OrderDetails == null)
            {
                vm.OrderDetails = new List<OrderDetail>();
            }

            if (btnAction == "AddItem")
            {
                if (ProductId != null && Qty != null && Qty > 0)
                {
                    var product = db.Products.Find(ProductId);

                    if (product == null)
                    {
                        TempData["ErrorMessage"] = "Product not found!";
                    }
                    else if (!product.IsActive)
                    {
                        TempData["ErrorMessage"] = $"{product.ProductName} is currently inactive!";
                    }
                    else if (Qty > product.AvailableQuantity)
                    {
                        TempData["ErrorMessage"] = $"Only {product.AvailableQuantity} items available for {product.ProductName}!";
                    }
                    else
                    {
                        var existingItem = vm.OrderDetails.FirstOrDefault(x => x.ProductId == ProductId);
                        if (existingItem != null)
                        {
                            if (existingItem.OrderQuantity + Qty > product.AvailableQuantity)
                            {
                                TempData["ErrorMessage"] = $"Total quantity exceeds available stock! Available: {product.AvailableQuantity}, Current: {existingItem.OrderQuantity}";
                            }
                            else
                            {
                                existingItem.OrderQuantity += Qty.Value;
                                existingItem.Amount = existingItem.OrderQuantity * existingItem.UnitPrice;
                            }
                        }
                        else
                        {
                            vm.OrderDetails.Add(new OrderDetail
                            {
                                ProductId = ProductId.Value,
                                Product = product,
                                OrderQuantity = Qty.Value,
                                UnitPrice = product.UnitPrice,
                                Amount = Qty.Value * product.UnitPrice,
                                OrderUnit = product.Unit
                            });
                        }
                    }
                }
                ModelState.Clear();
            }
            else if (btnAction == "UpdateItem")
            {
                if (editIndex != null && editIndex < vm.OrderDetails.Count && ProductId != null && Qty > 0)
                {
                    var product = db.Products.Find(ProductId);
                    if (product != null && product.IsActive)
                    {
                        if (Qty <= product.AvailableQuantity)
                        {
                            vm.OrderDetails[editIndex.Value].ProductId = ProductId.Value;
                            vm.OrderDetails[editIndex.Value].Product = product;
                            vm.OrderDetails[editIndex.Value].OrderQuantity = Qty.Value;
                            vm.OrderDetails[editIndex.Value].UnitPrice = product.UnitPrice;
                            vm.OrderDetails[editIndex.Value].Amount = Qty.Value * product.UnitPrice;
                            vm.OrderDetails[editIndex.Value].OrderUnit = product.Unit;
                        }
                        else
                        {
                            TempData["ErrorMessage"] = $"Only {product.AvailableQuantity} items available for {product.ProductName}!";
                        }
                    }
                }
                ModelState.Clear();
            }
            else if (btnAction == "RemoveItem")
            {
                if (removeIndex != null && removeIndex < vm.OrderDetails.Count)
                {
                    vm.OrderDetails.RemoveAt(removeIndex.Value);
                }
                ModelState.Clear();
            }
            else if (btnAction == "SaveOrder")
            {
                if (vm.OrderDetails != null && vm.OrderDetails.Any())
                {
                    if (string.IsNullOrEmpty(vm.CustomerName))
                    {
                        TempData["ErrorMessage"] = "Please enter customer name!";
                    }
                    else
                    {
                        try
                        {
                            using (var context = new ApplicationDbContext())
                            {
                                using (var transaction = context.Database.BeginTransaction())
                                {
                                    try
                                    {
                                        var existingOrder = context.Orders
                                            .Include(o => o.Customer)
                                            .Include(o => o.OrderDetails)
                                            .FirstOrDefault(o => o.OrderId == id);

                                        if (existingOrder != null)
                                        {
                                            // First, return quantities to products from old order details
                                            foreach (var oldDetail in existingOrder.OrderDetails)
                                            {
                                                var product = context.Products.Find(oldDetail.ProductId);
                                                if (product != null)
                                                {
                                                    product.AvailableQuantity += oldDetail.OrderQuantity;
                                                    context.Entry(product).State = EntityState.Modified;
                                                }
                                            }

                                            // Update customer
                                            existingOrder.Customer.CustomerName = vm.CustomerName;
                                            existingOrder.Customer.ContactNumber = vm.ContactNumber;
                                            existingOrder.Customer.ContactAddress = vm.ContactAddress;
                                            existingOrder.OrderDate = vm.OrderDate;
                                            existingOrder.TotalAmount = vm.OrderDetails.Sum(x => x.Amount);

                                            // Remove old order details
                                            context.OrderDetails.RemoveRange(existingOrder.OrderDetails);

                                            // Add new order details and deduct from available quantity
                                            foreach (var item in vm.OrderDetails)
                                            {
                                                item.OrderId = id;
                                                item.Product = null;
                                                context.OrderDetails.Add(item);

                                                // Update product available quantity
                                                var product = context.Products.Find(item.ProductId);
                                                if (product != null)
                                                {
                                                    product.AvailableQuantity -= item.OrderQuantity;
                                                    context.Entry(product).State = EntityState.Modified;
                                                }
                                            }
                                            context.SaveChanges();
                                            transaction.Commit();
                                        }
                                    }
                                    catch
                                    {
                                        transaction.Rollback();
                                        throw;
                                    }
                                }
                            }

                            TempData["SuccessMessage"] = "Order updated successfully!";
                            return RedirectToAction("Index");
                        }
                        catch (Exception ex)
                        {
                            TempData["ErrorMessage"] = "Error updating order: " + ex.Message;
                        }
                    }
                }
                else
                {
                    TempData["ErrorMessage"] = "Please add at least one product to the order!";
                }
            }

            // Reload product details for each order detail
            if (vm.OrderDetails != null)
            {
                foreach (var detail in vm.OrderDetails)
                {
                    if (detail.ProductId > 0 && detail.Product == null)
                    {
                        detail.Product = db.Products.Find(detail.ProductId);
                    }
                }
            }

            ViewBag.Categories = db.ProductCategories.ToList();
            ViewBag.ProductId = GetActiveProductsSelectList();
            return View(vm);
        }

        // AJAX: Get Products by Category
        [HttpGet]
        public ActionResult GetProductsByCategory(int categoryId)
        {
            var products = db.Products
                .Where(p => p.ProductCategoryId == categoryId && p.IsActive)
                .Select(p => new {
                    ProductId = p.ProductId,
                    ProductName = p.ProductName,
                    UnitPrice = p.UnitPrice,
                    AvailableQuantity = p.AvailableQuantity
                })
                .ToList();

            return Json(products, JsonRequestBehavior.AllowGet);
        }

        // AJAX: Get Product Category for Edit
        [HttpGet]
        public ActionResult GetProductCategory(int productId)
        {
            var product = db.Products.Find(productId);
            if (product != null)
            {
                return Json(new { categoryId = product.ProductCategoryId }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { categoryId = 0 }, JsonRequestBehavior.AllowGet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}