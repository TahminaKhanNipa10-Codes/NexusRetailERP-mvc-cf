using Evidence_MVC_MasterDetails_CF.Models;
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Evidence_MVC_MasterDetails_CF.Controllers
{
    public class BaseController : Controller
    {
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);

            // Get user permissions and set in ViewBag for all views
            if (User.Identity.IsAuthenticated)
            {
                using (var db = new ApplicationDbContext())
                {
                    var userId = User.Identity.GetUserId();
                    var userObj = db.Users.Find(userId);

                    if (userObj != null)
                    {
                        List<RolePermission> permissions = new List<RolePermission>();

                        // Admin users get all permissions
                        if (User.IsInRole("Admin"))
                        {
                            // For admin, we can show all possible actions
                            permissions = db.RolePermissions.ToList();
                        }
                        else
                        {
                            // For other users, get permissions based on their roles
                            var userRoles = userObj.Roles.Select(r => r.RoleId).ToList();
                            permissions = db.RolePermissions
                                .Where(p => userRoles.Contains(p.RoleId))
                                .ToList();
                        }

                        ViewBag.UserPermissions = permissions;
                    }
                }
            }
        }
    }
}
