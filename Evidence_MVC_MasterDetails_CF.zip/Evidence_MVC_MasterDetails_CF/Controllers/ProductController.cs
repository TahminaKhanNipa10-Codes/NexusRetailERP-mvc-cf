﻿using Evidence_MVC_MasterDetails_CF.Models;
using Evidence_MVC_MasterDetails_CF.Models.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Evidence_MVC_MasterDetails_CF.Controllers
{
    public class ProductController : BaseController
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Product
        public async Task<ActionResult> Index()
        {
            var products = await db.Products.Include(p => p.ProductCategory).ToListAsync();
            ViewBag.ProductCategoryId = new SelectList(await db.ProductCategories.ToListAsync(), "ProductCategoryId", "CategoryName");
            return View(products);
        }

        // GET: Product/Details/5
        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = await db.Products.FindAsync(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // GET: Product/Create
        public async Task<ActionResult> Create()
        {
            ViewBag.ProductCategoryId = new SelectList(await db.ProductCategories.ToListAsync(), "ProductCategoryId", "CategoryName");
            return View();
        }

        // POST: Product/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Product product)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    if (product.UploadImage != null && product.UploadImage.ContentLength > 0)
                    {
                        string fileName = Path.GetFileNameWithoutExtension(product.UploadImage.FileName);
                        string extension = Path.GetExtension(product.UploadImage.FileName);
                        HttpPostedFileBase postedFile = product.UploadImage;
                        int length = postedFile.ContentLength;
                        if (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png")
                        {
                            if (length <= 1000000)
                            {
                                fileName = fileName + extension;
                                product.ProductImage = "~/Images/" + fileName;
                                fileName = Path.Combine(Server.MapPath("~/Images/"), fileName);
                                
                                // Execute product creation within a transaction
                                await TransactionHelper.ExecuteInTransactionAsync(db, IsolationLevel.ReadCommitted, async (context) =>
                                {
                                    product.UploadImage.SaveAs(fileName);
                                    context.Products.Add(product);
                                    await context.SaveChangesAsync();
                                });

                                TempData["CreateMessage"] = "<script>alert('Record Inserted Successfully !!!!')</script>";
                                ModelState.Clear();
                                return RedirectToAction("Index", "Product");
                            }
                            else
                            {
                                TempData["SizeMessage"] = "<script>alert('File should be less then 10MB !!!!')</script>";
                            }
                        }
                        else
                        {
                            TempData["ExtensionMessage"] = "<script>alert('File format not supported!!!!')</script>";
                        }
                    }
                    else
                    {
                        TempData["ExtensionMessage"] = "<script>alert('Please select a product image!!!!')</script>";
                    }
                }
                catch (Exception ex)
                {
                    TempData["ErrorMessage"] = "<script>alert('Error: " + ex.Message + "')</script>";
                }
            }
            return View(product);
        }

        // GET: Product/Edit/5
        [HttpGet]
        public async Task<ActionResult> Edit(int? id)
        {
            var product = await db.Products.Where(model => model.ProductId == id).FirstOrDefaultAsync();
            Session["Image"] = product.ProductImage;
            ViewBag.ProductCategoryId = new SelectList(await db.ProductCategories.ToListAsync(), "ProductCategoryId", "CategoryName", product.ProductCategoryId);
            return View(product);

        }
      

        // POST: Product/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(Product product)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    if (product.UploadImage != null)
                    {
                        string fileName = Path.GetFileNameWithoutExtension(product.UploadImage.FileName);
                        string extension = Path.GetExtension(product.UploadImage.FileName);
                        HttpPostedFileBase postedFile = product.UploadImage;
                        int length = postedFile.ContentLength;
                        if (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png")
                        {
                            if (length <= 1000000)
                            {
                                fileName = fileName + extension;
                                product.ProductImage = "~/Images/" + fileName;
                                fileName = Path.Combine(Server.MapPath("~/Images/"), fileName);
                                
                                // Execute product update within a transaction
                                await TransactionHelper.ExecuteInTransactionAsync(db, IsolationLevel.ReadCommitted, async (context) =>
                                {
                                    product.UploadImage.SaveAs(fileName);
                                    context.Entry(product).State = EntityState.Modified;
                                    await context.SaveChangesAsync();
                                });

                                TempData["CreateMessage"] = "<script>alert('Record Updated Successfully !!!!')</script>";
                                ModelState.Clear();
                                return RedirectToAction("Index", "Product");
                            }
                            else
                            {
                                TempData["SizeMessage"] = "<script>alert('File should be less then 10MB !!!!')</script>";
                            }
                        }
                        else
                        {
                            TempData["ExtensionMessage"] = "<script>alert('File format not supported!!!!')</script>";
                        }
                    }
                    else
                    {
                        product.ProductImage = Session["Image"].ToString();
                        
                        // Execute product update within a transaction
                        await TransactionHelper.ExecuteInTransactionAsync(db, IsolationLevel.ReadCommitted, async (context) =>
                        {
                            context.Entry(product).State = EntityState.Modified;
                            await context.SaveChangesAsync();
                        });

                        TempData["UpdateMessage"] = "<script>alert('Record Updated Successfully!!!!')</script>";
                        ModelState.Clear();
                        return RedirectToAction("Index", "Product");
                    }
                }
                catch (Exception ex)
                {
                    TempData["ErrorMessage"] = "<script>alert('Error: " + ex.Message + "')</script>";
                }
            }
            ViewBag.ProductCategoryId = new SelectList(await db.ProductCategories.ToListAsync(), "ProductCategoryId", "CategoryName", product.ProductCategoryId);
            return View(product);
        }

        // GET: Product/Delete/5
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = await db.Products.FindAsync(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // POST: Product/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            try
            {
                await TransactionHelper.ExecuteInTransactionAsync(db, IsolationLevel.ReadCommitted, async (context) =>
                {
                    Product product = await context.Products.FindAsync(id);
                    if (product != null)
                    {
                        context.Products.Remove(product);
                        await context.SaveChangesAsync();
                    }
                });

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error deleting product: " + ex.Message;
                return RedirectToAction("Index");
            }
        }

        // AJAX: Search Products by Category and Name
        //[HttpPost]
        // AJAX: Search Products by Category and Name
        [HttpPost]
        public async Task<ActionResult> SearchProducts(int? categoryId, string productName)
        {
            var products = db.Products.Include(p => p.ProductCategory).AsQueryable();

            if (categoryId.HasValue && categoryId > 0)
            {
                products = products.Where(p => p.ProductCategoryId == categoryId);
            }

            if (!string.IsNullOrEmpty(productName))
            {
                products = products.Where(p => p.ProductName.Contains(productName));
            }

            var result = await products.ToListAsync();
            return PartialView("_ProductCards", result);
        }

        // AJAX: Toggle Product Status (Active/Inactive)
        [HttpPost]
        public async Task<JsonResult> ToggleProductStatus(int id)
        {
            try
            {
                await TransactionHelper.ExecuteInTransactionAsync(db, IsolationLevel.ReadCommitted, async (context) =>
                {
                    var product = await context.Products.FindAsync(id);
                    if (product == null)
                    {
                        throw new Exception("Product not found");
                    }

                    product.IsActive = !product.IsActive;
                    await context.SaveChangesAsync();
                });

                var product2 = await db.Products.FindAsync(id);
                string status = product2.IsActive ? "Active" : "Inactive";
                return Json(new { success = true, message = $"Product is now {status}", isActive = product2.IsActive });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
