﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Evidence_MVC_MasterDetails_CF.Filters;
using Evidence_MVC_MasterDetails_CF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Evidence_MVC_MasterDetails_CF.Controllers
{
    [Authorize]
    public class RolesController : BaseController
    {
        // GET: Roles
        [Authorize(Roles = "Admin")]
        public ActionResult Index()
        {
           
            var context = new Models.ApplicationDbContext();

            var rolelist = context.Roles.OrderBy(r => r.Name).ToList().Select(rr =>
            new SelectListItem
            {
               
                Value = rr.Id.ToString(),
                Text = rr.Name
            }).ToList();

            ViewBag.Roles = rolelist;

            var userlist = context.Users.OrderBy(u => u.UserName).ToList().Select(uu =>
            new SelectListItem { Value = uu.UserName.ToString(), Text = uu.UserName }).ToList();
            ViewBag.Users = userlist;

            ViewBag.Message = "";

            return View();
        }

        // GET: /Roles/Create
        [Authorize(Roles = "Admin")]
        public ActionResult Create()
        {
            return View();
        }

        
        // POST: /Roles/Create
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                var context = new Models.ApplicationDbContext();
                context.Roles.Add(new Microsoft.AspNet.Identity.EntityFramework.IdentityRole()
                {
                    Name = collection["RoleName"]
                });
                context.SaveChanges();
                ViewBag.Message = "Role created successfully !";
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        [CustomAuthorize]
        public ActionResult Delete(string RoleName)
        {
            var context = new Models.ApplicationDbContext();
            var thisRole = context.Roles.Where(r => r.Name.Equals(RoleName, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();
            context.Roles.Remove(thisRole);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        //
        // GET: /Roles/Edit/5
        [Authorize(Roles = "Admin")]
        public ActionResult Edit(string roleName)
        {
            var context = new Models.ApplicationDbContext();
            var thisRole = context.Roles.Where(r => r.Name.Equals(roleName, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();
            return View(thisRole);
        }

        
        // POST: /Roles/Edit/5
        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Microsoft.AspNet.Identity.EntityFramework.IdentityRole role)
        {
            try
            {
                var context = new Models.ApplicationDbContext();
                context.Entry(role).State = System.Data.Entity.EntityState.Modified;
                context.SaveChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }


        //  Adding Roles to a user
        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
       
        public ActionResult RoleAddToUser(string UserName, string RoleName) 
        {
            var context = new Models.ApplicationDbContext();
            var user = context.Users.Where(u => u.UserName.Equals(UserName, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

           
            var role = context.Roles.Find(RoleName);
            string actualName = (role != null) ? role.Name : RoleName;

            var userStore = new UserStore<ApplicationUser>(context);
            var userManager = new UserManager<ApplicationUser>(userStore);

            userManager.AddToRole(user.Id, actualName);

            TempData["Message"] = "Role added to user successfully!";
            return RedirectToAction("Index");
        }


        //Getting a List of Roles for a User
        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult GetRoles(string UserName)
        {
            var context = new Models.ApplicationDbContext();
            
            // Always populate users and roles
            var userlist = context.Users.OrderBy(u => u.UserName).ToList().Select(uu =>
            new SelectListItem { Value = uu.UserName.ToString(), Text = uu.UserName }).ToList();
            ViewBag.Users = userlist;

            var rolelist = context.Roles.OrderBy(r => r.Name).ToList().Select(rr => 
            new SelectListItem { Value = rr.Name.ToString(), Text = rr.Name }).ToList();
            ViewBag.Roles = rolelist;
            
            if (!string.IsNullOrWhiteSpace(UserName))
            {
                ApplicationUser user = context.Users.Where(u => u.UserName.Equals(UserName, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

                if (user != null)
                {
                    var userStore = new UserStore<ApplicationUser>(context);
                    var userManager = new UserManager<ApplicationUser>(userStore);
                    var userRoles = userManager.GetRoles(user.Id);
                    ViewBag.RolesForThisUser = userRoles;
                    ViewBag.SelectedUserName = UserName;
                    ViewBag.SelectedUserForDisplay = UserName;

                    // Create a list of only the roles assigned to this user for the Remove Role dropdown
                    var userRoleList = userRoles.ToList().Select(roleName => new SelectListItem { Value = roleName, Text = roleName }).ToList();
                    ViewBag.UserRoles = userRoleList;
                    ViewBag.Message = "Roles retrieved successfully !";
                }
            }

            return View("Index");
        }

      
        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteRoleForUser(string UserName, string RoleName)
        {
            var context = new Models.ApplicationDbContext();
            var user = context.Users.Where(u => u.UserName.Equals(UserName, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

            var role = context.Roles.Find(RoleName);
            string actualName = (role != null) ? role.Name : RoleName;

            var userStore = new UserStore<ApplicationUser>(context);
            var userManager = new UserManager<ApplicationUser>(userStore);

            if (userManager.IsInRole(user.Id, actualName))
            {
                userManager.RemoveFromRole(user.Id, actualName);
                TempData["Message"] = "Role removed from user successfully!";
            }
            return RedirectToAction("Index");
        }

        private List<string> GetControllerActions()
        {
            List<string> actions = new List<string>();
           
            string[] allowedControllers = { "ProductCategory", "Product", "Order" };

            var types = System.Reflection.Assembly.GetExecutingAssembly().GetTypes()
                .Where(type => typeof(System.Web.Mvc.Controller).IsAssignableFrom(type)
                       && allowedControllers.Contains(type.Name.Replace("Controller", "")));

            foreach (var type in types)
            {
                var methods = type.GetMethods(System.Reflection.BindingFlags.Instance |
                                              System.Reflection.BindingFlags.DeclaredOnly |
                                              System.Reflection.BindingFlags.Public)
                    .Where(m => typeof(ActionResult).IsAssignableFrom(m.ReturnType));

                foreach (var method in methods)
                {
                    actions.Add(type.Name.Replace("Controller", "") + "-" + method.Name);
                }
            }
            return actions;
        }

        [Authorize(Roles = "Admin")]
        public ActionResult ManagePermission(string roleId)
        {
            var context = new Models.ApplicationDbContext();
            var role = context.Roles.Find(roleId);

            if (role == null)
            {
                return RedirectToAction("Index");
            }

            ViewBag.RoleName = role.Name;
            ViewBag.RoleId = roleId;
            ViewBag.AllActions = GetControllerActions();

           
           
            var currentPermissions = context.RolePermissions.Where(p => p.RoleId == roleId).ToList() ?? new List<RolePermission>();

            return View(currentPermissions);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult SavePermission(string roleId, List<string> selectedActions)
        {
            var context = new Models.ApplicationDbContext();

            
            var oldPermissions = context.RolePermissions.Where(p => p.RoleId == roleId);
            context.RolePermissions.RemoveRange(oldPermissions);

            if (selectedActions != null)
            {
                foreach (var action in selectedActions)
                {
                    var split = action.Split('-');
                    context.RolePermissions.Add(new RolePermission
                    {
                        RoleId = roleId,
                        ControllerName = split[0],
                        ActionName = split[1]
                    });
                }
            }
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        // AJAX: Get roles for a specific user
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public JsonResult GetUserRolesAjax(string userName)
        {
            if (string.IsNullOrWhiteSpace(userName))
            {
                return Json(new List<string>());
            }

            var context = new Models.ApplicationDbContext();
            ApplicationUser user = context.Users.Where(u => u.UserName.Equals(userName, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

            if (user == null)
            {
                return Json(new List<string>());
            }

            var userStore = new UserStore<ApplicationUser>(context);
            var userManager = new UserManager<ApplicationUser>(userStore);
            var userRoles = userManager.GetRoles(user.Id).ToList();

            return Json(userRoles);
        }


    }
}